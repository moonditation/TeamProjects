package com.example.myapplication.adapter;

import java.sql.Time;
import java.util.List;

public class Promise {
    String name;

    Time time;
    List<User> list;
    public Promise(String name){
        this.name = name;
    }


}
